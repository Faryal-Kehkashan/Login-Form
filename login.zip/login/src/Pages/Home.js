import './Home.css';
import React, {useState} from 'react';
import { Link } from "react-router-dom";
import Welcome from './Welcome';


function Home() {

  const [name, setName] = useState("");
  const [pass, setPass] = useState("");

  const changename = (e) => {
    setName(e.target.name);
  }

  const changepass = (e) => {
    setPass(e.target.password);
  }

  const handlesubmit = (e) => {
    e.preventDefault();
    <>
    <Welcome/>
    </>
  }

  return (
    <div className="App">
      <form onSubmit = {handlesubmit}>
        <label>Username </label>
        <input type="text" name = {name} onChange = {changename} placeholder = "UserName" required></input>

        <label>Password </label>
        <input type="password" name = {pass} onChange = {changepass} placeholder = "Password" required></input>
        
        <input type = "submit" id = "btn">
        </input>
        <Link to = "/User">Already Have an Account</Link>
      </form>
    </div>
  );
}

export default Home;
